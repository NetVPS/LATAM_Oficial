#!/bin/bash
#12-02-2022
clear && clear
msg -bar 
echo -e "\e[1;91     <<<<<< PROXIMAMENTE >>>>>"
msg -bar